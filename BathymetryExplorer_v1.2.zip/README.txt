============================================
    BATHYMETRY EXPLORER v1.2
    Mappe Batimetriche per Pesca Sportiva
============================================

TODO (v1.2.0 - 2026-01-14)
--------------------------
[x] FIX BUG: currentZonePolygon - RISOLTO (linea 2438-2439)
[x] Test editing campi salvati - SUPERATO
[x] Catch Log sistema registrazione catture - COMPLETATO
[x] Aggiornare ZIP distribuzione - BathymetryExplorer_v1.2.zip

DOCUMENTAZIONE TECNICA
----------------------
- HANDOVER_SESSIONE_BATHYMETRY_RULER_20260114.md
  Riepilogo sessione righello con errori commessi e stato funzionalita

- DOCUMENTAZIONE_TECNICA_RIGHELLO_20260114.md
  Riferimento completo righello: variabili, funzioni, API, strutture dati

- DOCUMENTAZIONE_TECNICA_CATCH_LOG_20260114.md
  Riferimento completo catch log: struttura dati, funzioni, costanti

INSTALLAZIONE
-------------
1. Estrai lo ZIP in una cartella qualsiasi
2. Apri index.html con il tuo browser (Chrome, Firefox, Safari, Edge)

Funziona su: Windows, macOS, Linux

CONTENUTO
---------
- index.html    : Applicazione principale
- zones_data.js : Dati campi di gara (modificabile)
- screenshots/  : Screenshot test Playwright

FUNZIONALITA
------------
- 6 layer batimetrici (EMODnet, GEBCO, NOAA, Esri...)
- Temperatura mare (SST), Clorofilla, Correnti, Onde, Vento
- Ricerca luoghi e coordinate GPS
- Preferiti salvati nel browser
- Campi di gara con zone e punti di raduno
- Export dati in JSON

RIGHELLO AVANZATO (v1.1.0)
--------------------------
- Misurazione distanze multipoint con preview tempo reale
- Visualizzazione miglia nautiche (nm) e km
- Chiusura poligono automatica cliccando sul primo punto
- Dialog salvataggio con auto-rilevamento luogo (geocoding)
- Modalita editing: trascina i punti per aggiustare posizioni
- Modifica campi salvati con drag dei vertici

CATCH LOG (v1.2.0)
------------------
Sistema di registrazione catture con workflow semplificato:

WORKFLOW IN 2 PASSI:
1. SEGNA: Clicca "Segna" + click mappa (o "GPS" per smartphone)
   -> Il punto viene salvato SUBITO con coordinate e ora
   -> Funziona anche all'interno dei campi di gara (zone poligonali)
2. COMPLETA: Clicca sul punto (lista o marker sulla mappa):
   - Tipo evento (Strike, Rilascio, Avvistamento, Cattura Pesata)
   - Specie (18 specie italiane + possibilita di aggiungere custom)
   - Peso, Profondita, Esca, Meteo, Note, Foto

I punti "Da completare" sono evidenziati con:
- Icona grigia con ? sulla mappa (click apre dialog modifica)
- Bordo arancione pulsante nella lista

SPECIE DISPONIBILI (italiano):
- Grandi pelagici: Tonno Rosso, Tonno Pinna Gialla, Alalunga,
  Marlin Blu, Marlin Bianco, Pesce Spada, Aguglia Imperiale
- Pelagici medi: Lampuga, Ricciola, Leccia, Leccia Stella,
  Palamita, Tombarello
- Predatori: Dentice, Cernia, Spigola, Barracuda
- Custom: seleziona "Altra specie..." per aggiungerne di nuove

Funzionalita:
- Salvataggio immediato (nessun form iniziale)
- Marker colorati per tipo sulla mappa
- Coordinate in formato DDM (es. N 40° 29.700' E 13° 50.319')
- Lista scrollabile con filtri tipo/specie
- Statistiche giornata (oggi/totale)
- Export dati in JSON e CSV
- Geolocation API per smartphone
- Persistenza dati in localStorage
- Specie personalizzate salvate nel browser

AGGIUNGERE CAMPI DI GARA
------------------------
Modifica zones_data.js seguendo questo formato:

{
    id: 'mio-torneo-2026',
    name: 'Nome Campo',
    tournament: 'Nome Torneo',
    year: 2026,
    gatheringPoint: {
        lat: 40.1234,
        lng: 14.5678,
        name: 'Punto di Raduno'
    },
    vertices: [
        { lat: 40.1, lng: 14.5 },
        { lat: 40.2, lng: 14.6 },
        { lat: 40.1, lng: 14.7 },
        { lat: 40.0, lng: 14.6 }
    ],
    color: '#8b5cf6'
}

NOTE TECNICHE
-------------
- Richiede connessione internet per i layer WMS
- I preferiti sono salvati in localStorage del browser
- Testato su Chrome 120+, Firefox 120+, Safari 17+
- Formula distanza: Haversine (great-circle)
- Conversione: 1 nm = 1.852 km

LICENZA
-------
Uso libero per scopi non commerciali.
Layer cartografici soggetti alle rispettive licenze.

============================================
