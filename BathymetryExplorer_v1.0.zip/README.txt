============================================
    BATHYMETRY EXPLORER v1.0
    Mappe Batimetriche per Pesca Sportiva
============================================

INSTALLAZIONE
-------------
1. Estrai lo ZIP in una cartella qualsiasi
2. Apri index.html con il tuo browser (Chrome, Firefox, Safari, Edge)

Funziona su: Windows, macOS, Linux

CONTENUTO
---------
- index.html    : Applicazione principale
- zones_data.js : Dati campi di gara (modificabile)

FUNZIONALITA
------------
- 6 layer batimetrici (EMODnet, GEBCO, NOAA, Esri...)
- Temperatura mare (SST), Clorofilla, Correnti, Onde, Vento
- Ricerca luoghi e coordinate GPS
- Preferiti salvati nel browser
- Campi di gara con zone e punti di raduno
- Export dati in JSON

AGGIUNGERE CAMPI DI GARA
------------------------
Modifica zones_data.js seguendo questo formato:

{
    id: 'mio-torneo-2026',
    name: 'Nome Campo',
    tournament: 'Nome Torneo',
    year: 2026,
    gatheringPoint: {
        lat: 40.1234,
        lng: 14.5678,
        name: 'Punto di Raduno'
    },
    vertices: [
        { lat: 40.1, lng: 14.5 },
        { lat: 40.2, lng: 14.6 },
        { lat: 40.1, lng: 14.7 },
        { lat: 40.0, lng: 14.6 }
    ],
    color: '#8b5cf6'
}

NOTE TECNICHE
-------------
- Richiede connessione internet per i layer WMS
- I preferiti sono salvati in localStorage del browser
- Testato su Chrome 120+, Firefox 120+, Safari 17+

LICENZA
-------
Uso libero per scopi non commerciali.
Layer cartografici soggetti alle rispettive licenze.

============================================
